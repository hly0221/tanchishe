document.addEventListener('DOMContentLoaded', () => {
    // 获取画布和上下文
    const canvas = document.getElementById('tetris');
    const context = canvas.getContext('2d');
    const nextPieceCanvas = document.getElementById('nextPiece');
    const nextPieceContext = nextPieceCanvas.getContext('2d');
    
    // 设置方块大小和游戏区域大小
    const blockSize = 30;
    const rows = 20;
    const cols = 10;
    
    // 游戏状态
    let score = 0;
    let level = 1;
    let lines = 0;
    let gameOver = false;
    let isPaused = false;
    let gameStarted = false;
    let dropCounter = 0;
    let dropInterval = 1000; // 初始下落速度，1秒一次
    let lastTime = 0;
    
    // 游戏板
    const board = Array.from({length: rows}, () => Array(cols).fill(0));
    
    // 方块颜色
    const colors = [
        null,
        '#FF0D72', // I
        '#0DC2FF', // J
        '#0DFF72', // L
        '#F538FF', // O
        '#FF8E0D', // S
        '#FFE138', // T
        '#3877FF'  // Z
    ];
    
    // 方块形状
    const pieces = [
        // I
        [
            [0, 1, 0, 0],
            [0, 1, 0, 0],
            [0, 1, 0, 0],
            [0, 1, 0, 0]
        ],
        // J
        [
            [0, 2, 0],
            [0, 2, 0],
            [2, 2, 0]
        ],
        // L
        [
            [0, 3, 0],
            [0, 3, 0],
            [0, 3, 3]
        ],
        // O
        [
            [4, 4],
            [4, 4]
        ],
        // S
        [
            [0, 5, 5],
            [5, 5, 0],
            [0, 0, 0]
        ],
        // T
        [
            [0, 0, 0],
            [6, 6, 6],
            [0, 6, 0]
        ],
        // Z
        [
            [7, 7, 0],
            [0, 7, 7],
            [0, 0, 0]
        ]
    ];
    
    // 当前方块和下一个方块
    let currentPiece = null;
    let nextPiece = null;
    
    // 创建新方块
    function createPiece() {
        const pieceType = Math.floor(Math.random() * pieces.length);
        const piece = {
            position: {x: Math.floor(cols / 2) - Math.floor(pieces[pieceType][0].length / 2), y: 0},
            shape: pieces[pieceType],
            type: pieceType + 1
        };
        return piece;
    }
    
    // 绘制方块
    function drawBlock(x, y, color) {
        context.fillStyle = color;
        context.fillRect(x * blockSize, y * blockSize, blockSize, blockSize);
        context.strokeStyle = '#000';
        context.strokeRect(x * blockSize, y * blockSize, blockSize, blockSize);
    }
    
    // 绘制游戏板
    function drawBoard() {
        context.clearRect(0, 0, canvas.width, canvas.height);
        
        // 绘制已固定的方块
        for (let y = 0; y < rows; y++) {
            for (let x = 0; x < cols; x++) {
                if (board[y][x] !== 0) {
                    drawBlock(x, y, colors[board[y][x]]);
                }
            }
        }
        
        // 绘制当前方块
        if (currentPiece) {
            currentPiece.shape.forEach((row, y) => {
                row.forEach((value, x) => {
                    if (value !== 0) {
                        drawBlock(x + currentPiece.position.x, y + currentPiece.position.y, colors[value]);
                    }
                });
            });
        }
    }
    
    // 绘制下一个方块
    function drawNextPiece() {
        nextPieceContext.clearRect(0, 0, nextPieceCanvas.width, nextPieceCanvas.height);
        
        if (nextPiece) {
            const offsetX = (nextPieceCanvas.width / blockSize - nextPiece.shape[0].length) / 2;
            const offsetY = (nextPieceCanvas.height / blockSize - nextPiece.shape.length) / 2;
            
            nextPiece.shape.forEach((row, y) => {
                row.forEach((value, x) => {
                    if (value !== 0) {
                        nextPieceContext.fillStyle = colors[value];
                        nextPieceContext.fillRect((x + offsetX) * blockSize, (y + offsetY) * blockSize, blockSize, blockSize);
                        nextPieceContext.strokeStyle = '#000';
                        nextPieceContext.strokeRect((x + offsetX) * blockSize, (y + offsetY) * blockSize, blockSize, blockSize);
                    }
                });
            });
        }
    }
    
    // 碰撞检测
    function collide() {
        for (let y = 0; y < currentPiece.shape.length; y++) {
            for (let x = 0; x < currentPiece.shape[y].length; x++) {
                if (currentPiece.shape[y][x] !== 0 &&
                    (board[y + currentPiece.position.y] === undefined ||
                     board[y + currentPiece.position.y][x + currentPiece.position.x] === undefined ||
                     board[y + currentPiece.position.y][x + currentPiece.position.x] !== 0)) {
                    return true;
                }
            }
        }
        return false;
    }
    
    // 合并方块到游戏板
    function merge() {
        currentPiece.shape.forEach((row, y) => {
            row.forEach((value, x) => {
                if (value !== 0) {
                    board[y + currentPiece.position.y][x + currentPiece.position.x] = value;
                }
            });
        });
    }
    
    // 旋转方块
    function rotate() {
        const rotated = [];
        for (let i = 0; i < currentPiece.shape[0].length; i++) {
            const row = [];
            for (let j = currentPiece.shape.length - 1; j >= 0; j--) {
                row.push(currentPiece.shape[j][i]);
            }
            rotated.push(row);
        }
        
        const originalShape = currentPiece.shape;
        currentPiece.shape = rotated;
        
        // 如果旋转后发生碰撞，则恢复原状
        if (collide()) {
            currentPiece.shape = originalShape;
        }
    }
    
    // 移动方块
    function move(direction) {
        currentPiece.position.x += direction;
        if (collide()) {
            currentPiece.position.x -= direction;
        }
    }
    
    // 下落方块
    function drop() {
        currentPiece.position.y++;
        if (collide()) {
            currentPiece.position.y--;
            merge();
            checkLines();
            resetPiece();
            updateScore();
            
            // 检查游戏是否结束
            if (collide()) {
                gameOver = true;
                alert('游戏结束！你的分数是: ' + score);
                resetGame();
            }
        }
        dropCounter = 0;
    }
    
    // 硬降（直接落到底部）
    function hardDrop() {
        while (!collide()) {
            currentPiece.position.y++;
        }
        currentPiece.position.y--;
        drop();
    }
    
    // 检查并清除已满的行
    function checkLines() {
        let linesCleared = 0;
        
        outer: for (let y = rows - 1; y >= 0; y--) {
            for (let x = 0; x < cols; x++) {
                if (board[y][x] === 0) {
                    continue outer;
                }
            }
            
            // 移除已满的行
            const row = board.splice(y, 1)[0].fill(0);
            board.unshift(row);
            y++; // 检查同一行（现在是新行）
            linesCleared++;
        }
        
        // 更新消除的行数
        if (linesCleared > 0) {
            lines += linesCleared;
            document.getElementById('lines').textContent = lines;
            
            // 根据消除的行数增加分数
            switch (linesCleared) {
                case 1:
                    score += 100 * level;
                    break;
                case 2:
                    score += 300 * level;
                    break;
                case 3:
                    score += 500 * level;
                    break;
                case 4:
                    score += 800 * level;
                    break;
            }
            
            // 每消除10行提升一个等级
            if (lines >= level * 10) {
                level++;
                document.getElementById('level').textContent = level;
                // 提高下落速度
                dropInterval = Math.max(100, 1000 - (level - 1) * 100);
            }
        }
    }
    
    // 重置方块
    function resetPiece() {
        currentPiece = nextPiece || createPiece();
        nextPiece = createPiece();
        drawNextPiece();
    }
    
    // 更新分数显示
    function updateScore() {
        document.getElementById('score').textContent = score;
    }
    
    // 重置游戏
    function resetGame() {
        // 清空游戏板
        for (let y = 0; y < rows; y++) {
            for (let x = 0; x < cols; x++) {
                board[y][x] = 0;
            }
        }
        
        // 重置游戏状态
        score = 0;
        level = 1;
        lines = 0;
        gameOver = false;
        isPaused = false;
        gameStarted = false;
        dropInterval = 1000;
        
        // 更新显示
        document.getElementById('score').textContent = score;
        document.getElementById('level').textContent = level;
        document.getElementById('lines').textContent = lines;
        
        // 重置按钮
        document.getElementById('start-button').textContent = '开始游戏';
        document.getElementById('pause-button').textContent = '暂停';
        document.getElementById('pause-button').disabled = true;
        
        // 清空画布
        context.clearRect(0, 0, canvas.width, canvas.height);
        nextPieceContext.clearRect(0, 0, nextPieceCanvas.width, nextPieceCanvas.height);
        
        // 取消动画循环
        if (animationId) {
            cancelAnimationFrame(animationId);
            animationId = null;
        }
    }
    
    // 游戏循环
    let animationId = null;
    function update(time = 0) {
        if (gameOver || !gameStarted || isPaused) {
            return;
        }
        
        const deltaTime = time - lastTime;
        lastTime = time;
        
        dropCounter += deltaTime;
        if (dropCounter > dropInterval) {
            drop();
        }
        
        drawBoard();
        animationId = requestAnimationFrame(update);
    }
    
    // 键盘控制
    document.addEventListener('keydown', event => {
        if (!gameStarted || gameOver || isPaused) {
            return;
        }
        
        switch (event.keyCode) {
            case 37: // 左箭头
                move(-1);
                break;
            case 39: // 右箭头
                move(1);
                break;
            case 40: // 下箭头
                drop();
                break;
            case 38: // 上箭头
                rotate();
                break;
            case 32: // 空格
                hardDrop();
                break;
            case 80: // P键
                togglePause();
                break;
        }
    });
    
    // 开始按钮
    document.getElementById('start-button').addEventListener('click', () => {
        if (!gameStarted) {
            gameStarted = true;
            document.getElementById('start-button').textContent = '重新开始';
            document.getElementById('pause-button').disabled = false;
            resetPiece();
            lastTime = performance.now();
            update();
        } else {
            resetGame();
        }
    });
    
    // 暂停按钮
    document.getElementById('pause-button').addEventListener('click', togglePause);
    document.getElementById('pause-button').disabled = true;
    
    // 暂停/继续游戏
    function togglePause() {
        if (!gameStarted || gameOver) {
            return;
        }
        
        isPaused = !isPaused;
        document.getElementById('pause-button').textContent = isPaused ? '继续' : '暂停';
        
        if (!isPaused) {
            lastTime = performance.now();
            update();
        }
    }
    
    // 初始化游戏
    resetGame();
});