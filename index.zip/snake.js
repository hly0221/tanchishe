/**
 * 贪吃蛇游戏
 * 一个简单的HTML5 Canvas实现的贪吃蛇游戏
 */

// 获取DOM元素
const canvas = document.getElementById('game-canvas');
const ctx = canvas.getContext('2d');
const scoreElement = document.getElementById('score');
const coinsElement = document.getElementById('coins');
const timerElement = document.getElementById('timer');
const timerContainer = document.getElementById('timer-container');
const startButton = document.getElementById('start-btn');
const pauseButton = document.getElementById('pause-btn');
const difficultySelect = document.getElementById('difficulty');
const snakeColorSelect = document.getElementById('snake-color');
const gameModeSelect = document.getElementById('game-mode');

// 游戏配置
const config = {
    gridSize: 20,
    gridWidth: canvas.width / 20,
    gridHeight: canvas.height / 20,
    initialSpeed: {
        easy: 200,
        medium: 150,
        hard: 100
    },
    colors: {
        background: '#e8f5e9',
        border: '#81c784',
        snakeColors: {
            green: {
                body: '#388e3c',
                head: '#1b5e20'
            },
            blue: {
                body: '#1976d2',
                head: '#0d47a1'
            },
            purple: {
                body: '#7b1fa2',
                head: '#4a148c'
            },
            orange: {
                body: '#ef6c00',
                head: '#e65100'
            },
            pink: {
                body: '#d81b60',
                head: '#880e4f'
            }
        }
    },
    foodTypes: [
        { name: '草莓', color: '#e91e63', radius: 0.4 },
        { name: '苹果', color: '#f44336', radius: 0.45 },
        { name: '橘子', color: '#ff9800', radius: 0.45 },
        { name: '蓝莓', color: '#3f51b5', radius: 0.35 },
        { name: '香蕉', color: '#fdd835', radius: 0.4 },
        { name: '葡萄', color: '#9c27b0', radius: 0.4 },
        { name: '西瓜', color: '#4caf50', radius: 0.45 },
        { name: '樱桃', color: '#d32f2f', radius: 0.35 },
        { name: '柠檬', color: '#cddc39', radius: 0.4 }
    ],
    coinType: { name: '金币', color: '#ffc107', radius: 0.4 }
};

// 游戏状态
let game = {
    snake: [],
    foods: [], // 食物数组，可以存放多个食物
    coinItems: [], // 金币数组
    foodCount: 10, // 同时出现的食物数量
    coinCount: 3, // 同时出现的金币数量
    direction: 'right',
    nextDirection: 'right',
    score: 0,
    coins: 0, // 金币数量
    speed: config.initialSpeed.medium,
    isRunning: false,
    isPaused: false,
    gameLoop: null,
    timerLoop: null, // 限时模式计时器
    timeRemaining: 60, // 限时模式剩余时间（秒）
    targetScore: 100, // 限时模式目标分数
    gameMode: 'classic', // 游戏模式：classic（经典）或 timed（限时）
    snakeColor: 'green' // 默认蛇的颜色
};

// 页面加载时初始化游戏
window.addEventListener('DOMContentLoaded', function() {
    // 绑定开始按钮事件
    startButton.addEventListener('click', startGame);
    
    // 绑定暂停按钮事件
    pauseButton.addEventListener('click', togglePause);
    
    // 绑定键盘事件
    document.addEventListener('keydown', handleKeydown);
    
    // 绑定触摸事件（移动设备支持）
    canvas.addEventListener('touchstart', handleTouchStart);
    canvas.addEventListener('touchmove', handleTouchMove);
    
    // 绑定其他控件事件
    difficultySelect.addEventListener('change', handleDifficultyChange);
    snakeColorSelect.addEventListener('change', handleSnakeColorChange);
    gameModeSelect.addEventListener('change', handleGameModeChange);
    
    // 初始化游戏
    initGame();
});

// 初始化游戏
function initGame() {
    // 初始化蛇
    game.snake = [
        { x: 5, y: 10 },
        { x: 4, y: 10 },
        { x: 3, y: 10 }
    ];
    
    // 初始化方向
    game.direction = 'right';
    game.nextDirection = 'right';
    
    // 初始化分数和金币
    game.score = 0;
    game.coins = 0;
    scoreElement.textContent = '0';
    coinsElement.textContent = '0';
    
    // 设置游戏速度
    const difficulty = difficultySelect.value;
    game.speed = config.initialSpeed[difficulty];
    
    // 设置蛇的颜色
    game.snakeColor = snakeColorSelect.value;
    
    // 设置游戏模式
    game.gameMode = gameModeSelect.value;
    
    // 如果是限时模式，初始化计时器
    if (game.gameMode === 'timed') {
        game.timeRemaining = 60;
        timerElement.textContent = game.timeRemaining;
        timerContainer.style.display = 'inline';
    } else {
        timerContainer.style.display = 'none';
    }
    
    // 清除之前的计时器
    if (game.timerLoop) {
        clearInterval(game.timerLoop);
        game.timerLoop = null;
    }
    
    // 生成食物和金币
    game.foods = [];
    game.coinItems = [];
    generateFood();
    generateCoins();
    
    // 更新游戏状态
    game.isRunning = false;
    game.isPaused = false;
    
    // 绘制初始状态
    draw();
    
    // 更新按钮文本
    startButton.textContent = '开始游戏';
    pauseButton.textContent = '暂停';
    pauseButton.disabled = true;
}

// 生成食物
function generateFood() {
    // 确保食物数组不超过指定数量
    while (game.foods.length < game.foodCount) {
        // 随机生成食物位置
        let foodPosition;
        let isValid;
        let attempts = 0;
        const maxAttempts = 100; // 防止无限循环
        
        do {
            attempts++;
            isValid = true;
            foodPosition = {
                x: Math.floor(Math.random() * config.gridWidth),
                y: Math.floor(Math.random() * config.gridHeight),
                // 随机选择一种食物类型
                type: Math.floor(Math.random() * config.foodTypes.length)
            };
            
            // 检查食物是否在蛇身上
            for (let segment of game.snake) {
                if (segment.x === foodPosition.x && segment.y === foodPosition.y) {
                    isValid = false;
                    break;
                }
            }
            
            // 检查食物是否与其他食物重叠
            for (let food of game.foods) {
                if (food.x === foodPosition.x && food.y === foodPosition.y) {
                    isValid = false;
                    break;
                }
            }
            
            // 检查食物是否与金币重叠
            for (let coin of game.coinItems) {
                if (coin.x === foodPosition.x && coin.y === foodPosition.y) {
                    isValid = false;
                    break;
                }
            }
            
            // 如果尝试次数过多，减少要生成的食物数量以避免无限循环
            if (attempts >= maxAttempts) {
                console.warn('无法找到合适的食物位置，减少食物数量');
                return; // 退出当前循环
            }
        } while (!isValid);
        
        game.foods.push(foodPosition);
    }
}

// 生成金币
function generateCoins() {
    // 确保金币数组不超过指定数量
    while (game.coinItems.length < game.coinCount) {
        // 随机生成金币位置
        let coinPosition;
        let isValid;
        let attempts = 0;
        const maxAttempts = 100; // 防止无限循环
        
        do {
            attempts++;
            isValid = true;
            coinPosition = {
                x: Math.floor(Math.random() * config.gridWidth),
                y: Math.floor(Math.random() * config.gridHeight)
            };
            
            // 检查金币是否在蛇身上
            for (let segment of game.snake) {
                if (segment.x === coinPosition.x && segment.y === coinPosition.y) {
                    isValid = false;
                    break;
                }
            }
            
            // 检查金币是否与食物重叠
            for (let food of game.foods) {
                if (food.x === coinPosition.x && food.y === coinPosition.y) {
                    isValid = false;
                    break;
                }
            }
            
            // 检查金币是否与其他金币重叠
            for (let coin of game.coinItems) {
                if (coin.x === coinPosition.x && coin.y === coinPosition.y) {
                    isValid = false;
                    break;
                }
            }
            
            // 如果尝试次数过多，减少要生成的金币数量以避免无限循环
            if (attempts >= maxAttempts) {
                console.warn('无法找到合适的金币位置，减少金币数量');
                return; // 退出当前循环
            }
        } while (!isValid);
        
        game.coinItems.push(coinPosition);
    }
}

// 绘制游戏
function draw() {
    // 清空画布
    ctx.fillStyle = config.colors.background;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    // 绘制边框
    ctx.strokeStyle = config.colors.border;
    ctx.lineWidth = 2;
    ctx.strokeRect(0, 0, canvas.width, canvas.height);
    
    // 绘制蛇
    game.snake.forEach((segment, index) => {
        // 获取当前选择的蛇颜色
        const snakeColorScheme = config.colors.snakeColors[game.snakeColor];
        
        // 蛇头和身体使用不同颜色
        ctx.fillStyle = index === 0 ? snakeColorScheme.head : snakeColorScheme.body;
        
        // 绘制矩形作为蛇的身体（简化性能）
        const x = segment.x * config.gridSize;
        const y = segment.y * config.gridSize;
        const size = config.gridSize - 1;
        
        ctx.fillRect(x, y, size, size);
        
        // 为蛇头添加眼睛
        if (index === 0) {
            ctx.fillStyle = 'white';
            
            // 根据方向绘制眼睛
            const eyeSize = config.gridSize / 5;
            const eyeOffset = config.gridSize / 3;
            
            let eyeX1, eyeY1, eyeX2, eyeY2;
            
            switch (game.direction) {
                case 'up':
                    eyeX1 = segment.x * config.gridSize + eyeOffset;
                    eyeY1 = segment.y * config.gridSize + eyeOffset;
                    eyeX2 = segment.x * config.gridSize + config.gridSize - eyeOffset - eyeSize;
                    eyeY2 = segment.y * config.gridSize + eyeOffset;
                    break;
                case 'down':
                    eyeX1 = segment.x * config.gridSize + eyeOffset;
                    eyeY1 = segment.y * config.gridSize + config.gridSize - eyeOffset - eyeSize;
                    eyeX2 = segment.x * config.gridSize + config.gridSize - eyeOffset - eyeSize;
                    eyeY2 = segment.y * config.gridSize + config.gridSize - eyeOffset - eyeSize;
                    break;
                case 'left':
                    eyeX1 = segment.x * config.gridSize + eyeOffset;
                    eyeY1 = segment.y * config.gridSize + eyeOffset;
                    eyeX2 = segment.x * config.gridSize + eyeOffset;
                    eyeY2 = segment.y * config.gridSize + config.gridSize - eyeOffset - eyeSize;
                    break;
                case 'right':
                    eyeX1 = segment.x * config.gridSize + config.gridSize - eyeOffset - eyeSize;
                    eyeY1 = segment.y * config.gridSize + eyeOffset;
                    eyeX2 = segment.x * config.gridSize + config.gridSize - eyeOffset - eyeSize;
                    eyeY2 = segment.y * config.gridSize + config.gridSize - eyeOffset - eyeSize;
                    break;
            }
            
            // 绘制圆形眼睛
            ctx.beginPath();
            ctx.arc(eyeX1 + eyeSize/2, eyeY1 + eyeSize/2, eyeSize/2, 0, Math.PI * 2);
            ctx.fill();
            
            ctx.beginPath();
            ctx.arc(eyeX2 + eyeSize/2, eyeY2 + eyeSize/2, eyeSize/2, 0, Math.PI * 2);
            ctx.fill();
            
            // 添加黑色瞳孔
            ctx.fillStyle = 'black';
            ctx.beginPath();
            ctx.arc(eyeX1 + eyeSize/2, eyeY1 + eyeSize/2, eyeSize/4, 0, Math.PI * 2);
            ctx.fill();
            
            ctx.beginPath();
            ctx.arc(eyeX2 + eyeSize/2, eyeY2 + eyeSize/2, eyeSize/4, 0, Math.PI * 2);
            ctx.fill();
        }
    });
    
    // 绘制多个食物
    for (let food of game.foods) {
        const foodType = config.foodTypes[food.type];
        const foodX = food.x * config.gridSize + config.gridSize / 2;
        const foodY = food.y * config.gridSize + config.gridSize / 2;
        const foodRadius = config.gridSize * foodType.radius;
        
        // 绘制食物主体
        ctx.fillStyle = foodType.color;
        ctx.beginPath();
        ctx.arc(foodX, foodY, foodRadius, 0, Math.PI * 2);
        ctx.fill();
        
        // 根据食物类型添加细节
        switch(foodType.name) {
            case '草莓':
                // 添加草莓顶部的绿色叶子
                ctx.fillStyle = '#4CAF50';
                ctx.beginPath();
                ctx.moveTo(foodX, foodY - foodRadius);
                ctx.lineTo(foodX - foodRadius/2, foodY - foodRadius - foodRadius/3);
                ctx.lineTo(foodX + foodRadius/2, foodY - foodRadius - foodRadius/3);
                ctx.closePath();
                ctx.fill();
                break;
                
            case '苹果':
                // 添加苹果顶部的绿色叶子和棕色梗
                ctx.fillStyle = '#795548';
                ctx.fillRect(foodX - 1, foodY - foodRadius - 3, 2, 3);
                
                ctx.fillStyle = '#4CAF50';
                ctx.beginPath();
                ctx.ellipse(foodX + 2, foodY - foodRadius, 3, 2, 0, 0, Math.PI * 2);
                ctx.fill();
                break;
                
            case '橘子':
                // 添加橘子表面的纹理
                ctx.strokeStyle = '#E65100';
                ctx.beginPath();
                ctx.moveTo(foodX - foodRadius/2, foodY);
                ctx.lineTo(foodX + foodRadius/2, foodY);
                ctx.stroke();
                
                ctx.beginPath();
                ctx.moveTo(foodX, foodY - foodRadius/2);
                ctx.lineTo(foodX, foodY + foodRadius/2);
                ctx.stroke();
                break;
                
            case '蓝莓':
                // 添加蓝莓顶部的小点
                ctx.fillStyle = '#E0E0E0';
                ctx.beginPath();
                ctx.arc(foodX, foodY - foodRadius/2, foodRadius/5, 0, Math.PI * 2);
                ctx.fill();
                break;
                
            case '香蕉':
                // 香蕉形状
                ctx.fillStyle = '#FDD835';
                ctx.beginPath();
                ctx.ellipse(foodX, foodY, foodRadius, foodRadius/2, Math.PI/4, 0, Math.PI * 2);
                ctx.fill();
                
                // 香蕉两端的黑色
                ctx.fillStyle = '#5D4037';
                ctx.beginPath();
                ctx.arc(foodX + foodRadius/2, foodY - foodRadius/2, 2, 0, Math.PI * 2);
                ctx.fill();
                break;
        }
    }
    
    // 绘制金币
    for (let coin of game.coinItems) {
        const coinX = coin.x * config.gridSize + config.gridSize / 2;
        const coinY = coin.y * config.gridSize + config.gridSize / 2;
        const coinRadius = config.gridSize * config.coinType.radius;
        
        // 绘制金币主体
        ctx.fillStyle = config.coinType.color;
        ctx.beginPath();
        ctx.arc(coinX, coinY, coinRadius, 0, Math.PI * 2);
        ctx.fill();
        
        // 添加金币的"$"符号
        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold ' + (config.gridSize * 0.5) + 'px Arial';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('$', coinX, coinY);
    }
}

// 更新游戏状态
function update() {
    // 更新蛇的方向
    game.direction = game.nextDirection;
    
    // 获取蛇头
    const head = { ...game.snake[0] };
    
    // 根据方向移动蛇头
    switch (game.direction) {
        case 'up':
            head.y--;
            break;
        case 'down':
            head.y++;
            break;
        case 'left':
            head.x--;
            break;
        case 'right':
            head.x++;
            break;
    }
    
    // 检查是否撞墙（更严格的边界检测）
    if (
        head.x < 0 || head.x >= config.gridWidth ||
        head.y < 0 || head.y >= config.gridHeight
    ) {
        gameOver();
        return;
    }
    
    // 检查是否撞到自己（直接比较坐标值，提高性能）
    for (let i = 1; i < game.snake.length; i++) {
        if (game.snake[i].x === head.x && game.snake[i].y === head.y) {
            gameOver();
            return;
        }
    }
    
    // 在蛇数组前添加新头部
    game.snake.unshift(head);
    
    // 检查是否吃到食物
    let foodEaten = false;
    for (let i = game.foods.length - 1; i >= 0; i--) {
        if (head.x === game.foods[i].x && head.y === game.foods[i].y) {
            // 增加分数
            game.score += 10;
            scoreElement.textContent = game.score;
            
            // 移除被吃掉的食物
            game.foods.splice(i, 1);
            
            // 生成新的食物
            generateFood();
            foodEaten = true;
            
            // 每得100分增加游戏难度，但确保速度变化更平滑
            if (game.score % 100 === 0 && game.score > 0) {
                // 使用更平滑的速度调整公式
                const minSpeed = 40; // 最快速度（最小延迟）
                const speedReduction = 0.9; // 速度减少因子
                
                // 确保速度不会低于最小值
                game.speed = Math.max(game.speed * speedReduction, minSpeed);
                restartGameLoop();
            }
            
            // 检查限时模式是否达成目标
            if (game.gameMode === 'timed' && game.score >= game.targetScore) {
                gameWin();
                return;
            }
            
            break; // 一次只能吃一个食物
        }
    }
    
    // 检查是否吃到金币
    for (let i = game.coinItems.length - 1; i >= 0; i--) {
        if (head.x === game.coinItems[i].x && head.y === game.coinItems[i].y) {
            // 增加金币数量
            game.coins++;
            coinsElement.textContent = game.coins;
            
            // 移除被吃掉的金币
            game.coinItems.splice(i, 1);
            
            // 生成新的金币
            generateCoins();
            
            break; // 一次只能吃一个金币
        }
    }
    
    if (!foodEaten) {
        // 如果没吃到食物，移除尾部
        game.snake.pop();
    }
}

// 游戏循环
function gameLoop() {
    if (!game.isPaused) {
        update();
        draw();
    }
}

// 重启游戏循环（当速度改变时）
function restartGameLoop() {
    clearInterval(game.gameLoop);
    game.gameLoop = setInterval(gameLoop, game.speed);
}

// 游戏结束
function gameOver() {
    clearInterval(game.gameLoop);
    if (game.timerLoop) {
        clearInterval(game.timerLoop);
        game.timerLoop = null;
    }
    game.isRunning = false;
    
    // 显示游戏结束信息
    ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    ctx.fillStyle = 'white';
    ctx.font = '30px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('游戏结束!', canvas.width / 2, canvas.height / 2 - 30);
    
    ctx.font = '20px Arial';
    ctx.fillText(`最终得分: ${game.score}`, canvas.width / 2, canvas.height / 2 + 10);
    ctx.fillText(`收集金币: ${game.coins}个`, canvas.width / 2, canvas.height / 2 + 40);
    
    // 如果是限时模式，显示额外信息
    if (game.gameMode === 'timed') {
        ctx.fillText(`目标分数: ${game.targetScore}`, canvas.width / 2, canvas.height / 2 + 70);
        ctx.fillText('按"开始游戏"重新开始', canvas.width / 2, canvas.height / 2 + 100);
    } else {
        ctx.fillText('按"开始游戏"重新开始', canvas.width / 2, canvas.height / 2 + 70);
    }
    
    // 更新按钮状态
    startButton.textContent = '重新开始';
    pauseButton.disabled = true;
}

// 游戏胜利
function gameWin() {
    clearInterval(game.gameLoop);
    if (game.timerLoop) {
        clearInterval(game.timerLoop);
        game.timerLoop = null;
    }
    game.isRunning = false;
    
    // 显示游戏胜利信息
    ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    ctx.fillStyle = '#4CAF50';
    ctx.font = '30px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('恭喜通关!', canvas.width / 2, canvas.height / 2 - 30);
    
    ctx.fillStyle = 'white';
    ctx.font = '20px Arial';
    ctx.fillText(`最终得分: ${game.score}`, canvas.width / 2, canvas.height / 2 + 10);
    ctx.fillText(`收集金币: ${game.coins}个`, canvas.width / 2, canvas.height / 2 + 40);
    ctx.fillText('按"开始游戏"重新开始', canvas.width / 2, canvas.height / 2 + 70);
    
    // 更新按钮状态
    startButton.textContent = '重新开始';
    pauseButton.disabled = true;
}

// 开始游戏
function startGame() {
    // 无论游戏是否在运行，都重置游戏
    clearInterval(game.gameLoop);
    if (game.timerLoop) {
        clearInterval(game.timerLoop);
        game.timerLoop = null;
    }
    
    // 完全重置游戏状态
    game.snake = [];
    game.foods = [];
    game.coinItems = [];
    game.direction = 'right';
    game.nextDirection = 'right';
    game.score = 0;
    game.coins = 0;
    game.isRunning = false;
    game.isPaused = false;
    
    initGame();
    
    game.isRunning = true;
    game.isPaused = false;
    
    // 更新按钮状态
    startButton.textContent = '重新开始';
    pauseButton.textContent = '暂停';
    pauseButton.disabled = false;
    
    // 启动游戏循环
    game.gameLoop = setInterval(gameLoop, game.speed);
    
    // 如果是限时模式，启动计时器
    if (game.gameMode === 'timed') {
        // 重置剩余时间
        game.timeRemaining = 60;
        timerElement.textContent = game.timeRemaining;
        
        game.timerLoop = setInterval(() => {
            if (!game.isPaused) {
                game.timeRemaining--;
                timerElement.textContent = game.timeRemaining;
                
                if (game.timeRemaining <= 0) {
                    gameOver();
                }
            }
        }, 1000);
    }
}

// 暂停/继续游戏
function togglePause() {
    if (!game.isRunning) return;
    
    game.isPaused = !game.isPaused;
    pauseButton.textContent = game.isPaused ? '继续' : '暂停';
    
    // 如果是限时模式，处理计时器
    if (game.gameMode === 'timed') {
        if (game.isPaused) {
            // 暂停时清除计时器
            clearInterval(game.timerLoop);
            game.timerLoop = null;
            
            // 显示暂停信息
            ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            
            ctx.fillStyle = 'white';
            ctx.font = '30px Arial';
            ctx.textAlign = 'center';
            ctx.fillText('游戏暂停', canvas.width / 2, canvas.height / 2);
        } else {
            // 继续时重新启动计时器
            // 确保先清除可能存在的计时器，避免多个计时器同时运行
            if (game.timerLoop) {
                clearInterval(game.timerLoop);
            }
            
            game.timerLoop = setInterval(() => {
                if (!game.isPaused) {
                    game.timeRemaining--;
                    timerElement.textContent = game.timeRemaining;
                    
                    if (game.timeRemaining <= 0) {
                        gameOver();
                    }
                }
            }, 1000);
            
            // 重新绘制游戏，覆盖暂停信息
            draw();
        }
    } else if (!game.isPaused) {
        // 非限时模式下，继续游戏时重新绘制
        draw();
    }
}

// 处理键盘输入
function handleKeydown(e) {
    if (!game.isRunning) return;
    
    // 防止方向键滚动页面
    if ([37, 38, 39, 40].includes(e.keyCode)) {
        e.preventDefault();
    }
    
    // 根据按键更新方向（增加输入验证）
    const validKeys = [37, 38, 39, 40, 32]; // 左、上、右、下、空格
    if (!validKeys.includes(e.keyCode)) return;
    
    // 确保不能直接掉头（例如，向右移动时不能直接向左转）
    switch (e.keyCode) {
        case 38: // 上箭头
            if (game.direction !== 'down') game.nextDirection = 'up';
            break;
        case 40: // 下箭头
            if (game.direction !== 'up') game.nextDirection = 'down';
            break;
        case 37: // 左箭头
            if (game.direction !== 'right') game.nextDirection = 'left';
            break;
        case 39: // 右箭头
            if (game.direction !== 'left') game.nextDirection = 'right';
            break;
        case 32: // 空格键 - 暂停/继续
            togglePause();
            break;
    }
}

// 难度改变事件处理
function handleDifficultyChange() {
    const difficulty = difficultySelect.value;
    game.speed = config.initialSpeed[difficulty];
    
    if (game.isRunning) {
        restartGameLoop();
    }
}

// 蛇颜色改变事件处理
function handleSnakeColorChange() {
    game.snakeColor = snakeColorSelect.value;
    
    // 如果游戏没有运行，重新绘制以显示新颜色
    if (!game.isRunning) {
        draw();
    }
}

// 游戏模式改变事件处理
function handleGameModeChange() {
    game.gameMode = gameModeSelect.value;
    
    // 更新计时器显示
    if (game.gameMode === 'timed') {
        timerContainer.style.display = 'inline';
        timerElement.textContent = '60';
    } else {
        timerContainer.style.display = 'none';
    }
    
    // 如果游戏没有运行，重新绘制
    if (!game.isRunning) {
        draw();
    }
}

// 事件监听器已在DOMContentLoaded中添加

// 触摸事件处理
let touchStartX = 0;
let touchStartY = 0;

// 处理触摸开始事件
function handleTouchStart(e) {
    if (!game.isRunning || game.isPaused) return;
    
    // 获取第一个触摸点的坐标
    const touch = e.touches[0];
    touchStartX = touch.clientX;
    touchStartY = touch.clientY;
    
    // 阻止默认行为（如滚动）
    e.preventDefault();
}

// 处理触摸移动事件
function handleTouchMove(e) {
    if (!game.isRunning || game.isPaused) return;
    
    // 如果没有触摸点，直接返回
    if (!e.touches.length) return;
    
    // 获取当前触摸点的坐标
    const touch = e.touches[0];
    const touchEndX = touch.clientX;
    const touchEndY = touch.clientY;
    
    // 计算水平和垂直方向的移动距离
    const deltaX = touchEndX - touchStartX;
    const deltaY = touchEndY - touchStartY;
    
    // 确定主要移动方向（水平或垂直）
    if (Math.abs(deltaX) > Math.abs(deltaY)) {
        // 水平移动
        if (deltaX > 0 && game.direction !== 'left') {
            // 向右滑动
            game.nextDirection = 'right';
        } else if (deltaX < 0 && game.direction !== 'right') {
            // 向左滑动
            game.nextDirection = 'left';
        }
    } else {
        // 垂直移动
        if (deltaY > 0 && game.direction !== 'up') {
            // 向下滑动
            game.nextDirection = 'down';
        } else if (deltaY < 0 && game.direction !== 'down') {
            // 向上滑动
            game.nextDirection = 'up';
        }
    }
    
    // 更新起始点为当前点，以便连续滑动
    touchStartX = touchEndX;
    touchStartY = touchEndY;
    
    // 阻止默认行为
    e.preventDefault();
}

// 游戏已在DOMContentLoaded事件中初始化