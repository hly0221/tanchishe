/**
 * 贪吃蛇游戏分享工具
 * 用于生成二维码和分享链接
 */

// 当分享页面加载完成时
document.addEventListener('DOMContentLoaded', function() {
    // 检查是否在share.html页面
    if (document.getElementById('qrcode')) {
        // 初始化二维码
        initQRCode();
        
        // 绑定事件
        bindEvents();
    }
});

// 初始化二维码
function initQRCode() {
    const urlInput = document.getElementById('url-input');
    const qrcodeContainer = document.getElementById('qrcode');
    
    // 尝试获取当前页面的URL（去掉share.html）
    let baseUrl = window.location.href.replace('share.html', '');
    if (baseUrl.endsWith('/')) {
        baseUrl += 'snake.html';
    } else {
        baseUrl += '/snake.html';
    }
    
    // 设置默认URL
    urlInput.value = baseUrl;
    
    // 检查QRCode库是否已加载
    if (typeof QRCode === 'undefined') {
        console.warn('QRCode库未加载，尝试动态加载...');
        
        // 显示加载中提示
        qrcodeContainer.innerHTML = '<div style="padding: 20px; text-align: center;">正在加载二维码生成器...</div>';
        
        // 尝试动态加载QRCode库
        const script = document.createElement('script');
        script.src = 'https://cdn.jsdelivr.net/npm/qrcodejs@1.0.0/qrcode.min.js';
        script.onload = function() {
            console.log('QRCode库加载成功');
            // 库加载成功后生成二维码
            generateQRCode(baseUrl);
        };
        script.onerror = function() {
            console.error('QRCode库加载失败，尝试备用库');
            // 尝试备用CDN
            const backupScript = document.createElement('script');
            backupScript.src = 'https://cdn.rawgit.com/davidshimjs/qrcodejs/gh-pages/qrcode.min.js';
            backupScript.onload = function() {
                generateQRCode(baseUrl);
            };
            backupScript.onerror = function() {
                // 所有CDN都失败，使用备用方法
                generateFallbackQRCode(baseUrl, qrcodeContainer);
            };
            document.head.appendChild(backupScript);
        };
        document.head.appendChild(script);
    } else {
        // QRCode库已加载，直接生成二维码
        generateQRCode(baseUrl);
    }
}

// 生成二维码
function generateQRCode(url) {
    const qrcodeContainer = document.getElementById('qrcode');
    if (!qrcodeContainer) return;
    
    // 清空容器
    qrcodeContainer.innerHTML = '';
    
    try {
        // 检查QRCode库是否正确加载
        if (typeof QRCode === 'undefined') {
            throw new Error('QRCode库未正确加载');
        }
        
        // 使用QRCode.js库生成二维码
        new QRCode(qrcodeContainer, {
            text: url,
            width: 200,
            height: 200,
            colorDark: '#000000',
            colorLight: '#ffffff',
            correctLevel: QRCode.CorrectLevel.H
        });
    } catch (error) {
        console.error('生成二维码时出错:', error);
        
        // 显示错误信息
        qrcodeContainer.innerHTML = `
            <div style="border: 1px solid #f44336; padding: 10px; text-align: left; background-color: #ffebee;">
                <p style="color: #d32f2f; margin: 0 0 10px 0;"><strong>无法生成二维码</strong></p>
                <p style="margin: 0;">可能原因:</p>
                <ul style="margin: 5px 0; padding-left: 20px;">
                    <li>QRCode.js库加载失败</li>
                    <li>网络连接问题</li>
                    <li>浏览器兼容性问题</li>
                </ul>
                <p style="margin: 5px 0 0 0;">请尝试刷新页面或使用其他分享方式。</p>
            </div>
        `;
        
        // 尝试加载备用QRCode库
        const script = document.createElement('script');
        script.src = 'https://cdn.rawgit.com/davidshimjs/qrcodejs/gh-pages/qrcode.min.js';
        script.onload = function() {
            // 库加载成功后重试
            try {
                qrcodeContainer.innerHTML = '';
                new QRCode(qrcodeContainer, {
                    text: url,
                    width: 200,
                    height: 200
                });
            } catch (e) {
                console.error('使用备用库生成二维码失败:', e);
            }
        };
        document.head.appendChild(script);
    }
}

// 绑定事件
function bindEvents() {
    // 生成二维码按钮
    const generateBtn = document.getElementById('generate-qr');
    if (generateBtn) {
        generateBtn.addEventListener('click', function() {
            const url = document.getElementById('url-input').value.trim();
            if (url) {
                generateQRCode(url);
            }
        });
    }
    
    // 下载ZIP按钮
    const downloadBtn = document.getElementById('download-zip');
    if (downloadBtn) {
        downloadBtn.addEventListener('click', function(e) {
            e.preventDefault();
            alert('在实际部署中，这里会触发游戏文件的ZIP下载。\n\n您可以手动将游戏文件夹压缩成ZIP文件进行分享。');
        });
    }
}

// 简单的备用二维码生成函数（不依赖外部库）
function generateFallbackQRCode(url, container) {
    // 创建一个链接，用户可以点击访问
    const fallbackLink = document.createElement('div');
    fallbackLink.innerHTML = `
        <div style="border: 1px solid #2196f3; padding: 15px; text-align: center; background-color: #e3f2fd;">
            <p style="margin: 0 0 10px 0;"><strong>无法自动生成二维码</strong></p>
            <p style="margin: 0 0 15px 0;">您可以使用以下链接访问游戏：</p>
            <a href="${url}" target="_blank" style="
                display: inline-block;
                word-break: break-all;
                max-width: 100%;
                padding: 8px 15px;
                background-color: #2196f3;
                color: white;
                text-decoration: none;
                border-radius: 4px;
                margin-bottom: 10px;
            ">${url}</a>
            <p style="margin: 10px 0 0 0; font-size: 0.9em;">
                或者使用在线二维码生成工具：
                <a href="https://www.qr-code-generator.com/" target="_blank">QR Code Generator</a>
            </p>
        </div>
    `;
    container.appendChild(fallbackLink);
}

// 导出函数，可以在其他页面使用
window.shareGame = {
    generateQRCode: generateQRCode,
    generateFallbackQRCode: generateFallbackQRCode
};